import java.util.*;
public class Test {
	public static void main(String[] args) {
		ArrayList<Interval> intervals = new ArrayList<Interval>();
		intervals.add( new Interval(1,3) );
		intervals.add( new Interval(2,6) );
		intervals.add( new Interval(8,10) );
		intervals.add( new Interval(15,18));
		ArrayList<Interval> result = Solution.merge(intervals);

		for(int i=0; i<result.size(); i++) {
			System.out.print(result.get(i).start);
			System.out.print(" ");
			System.out.println(result.get(i).end);
		}
	}
}