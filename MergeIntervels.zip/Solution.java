/**
 * Definition for an interval.
 * public class Interval {
 *     int start;
 *     int end;
 *     Interval() { start = 0; end = 0; }
 *     Interval(int s, int e) { start = s; end = e; }
 * }
 */
import java.util.*;

public class Solution {
    public static ArrayList<Interval> merge(ArrayList<Interval> intervals) {
		if(intervals == null || intervals.size()<=1) return intervals;
		
		// sort intervals
		Collections.sort(intervals, new MyComparator() );

		// add intervals one by one
		ArrayList<Interval> result = new ArrayList<Interval>();
		result.add(	intervals.get(0) );
		for(int i=0; i<intervals.size(); i++) {
			Interval tmp_interval = intervals.get(i);
			Interval last_interval = result.get( result.size()-1);
			if( last_interval.end >= tmp_interval.end ) {
				continue;
			} else if (last_interval.end >= tmp_interval.start && last_interval.end<tmp_interval.end) {
				last_interval.end = tmp_interval.end;
			} else {
				result.add(tmp_interval);
			}
		}
		return result;
    }
}

class MyComparator implements Comparator<Interval> {
	public int compare(Interval o1, Interval o2) {
		if(o1.start < o2.start) {
			return -1;
		} else if (o1.start == o2.start) {
			return 0;
		} else {
			return 1;
		}
	}
}